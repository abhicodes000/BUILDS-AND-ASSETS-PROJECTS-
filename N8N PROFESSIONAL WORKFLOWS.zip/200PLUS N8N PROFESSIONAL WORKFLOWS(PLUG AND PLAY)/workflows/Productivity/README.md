# Productivity Templates

- **morning_briefing_email.json** – Uses Anthropic Claude, Cohere Embeddings, Supabase Vector