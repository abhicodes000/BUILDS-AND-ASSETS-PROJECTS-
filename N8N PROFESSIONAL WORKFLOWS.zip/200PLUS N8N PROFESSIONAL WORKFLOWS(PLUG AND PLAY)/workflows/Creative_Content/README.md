# Creative_Content Templates

- **youtube_transcript_to_blog.json** – Uses Anthropic Claude, OpenAI Embeddings, Pinecone